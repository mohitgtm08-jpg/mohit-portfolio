# Mohit Gautam | Portfolio

Personal portfolio website built with plain HTML, CSS and JavaScript.

## Run locally
Open `index.html` in a browser. No build step needed.

## Structure
- `index.html`: page content
- `style.css`: styles (dark theme, responsive)
- `script.js`: typing effect, scroll reveal, mobile menu, nav highlighting
- `assets/`: put your resume (`resume.pdf`), photo and project screenshots here

## To do
- Add `assets/resume.pdf` and uncomment the resume button in `index.html`
- Add GitHub links for AI Resume Analyser and Crop Disease Detection
- Add your graduation year in the Education section
- Deploy with GitHub Pages or Netlify
