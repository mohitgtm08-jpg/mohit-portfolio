/* ===== 1. Typing Animation ===== */

const typingText = document.getElementById("typing-text");

const roles = [
    "an AI/ML Student",
    "a Python Developer",
    "an LLM App Builder",
    "a Computer Vision Learner"
];

const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
).matches;

let roleIndex = 0;
let charIndex = 0;
let deleting = false;

function typeEffect() {
    const currentRole = roles[roleIndex];

    if (deleting) {
        charIndex--;
    } else {
        charIndex++;
    }

    typingText.textContent = currentRole.substring(0, charIndex);

    let delay = deleting ? 45 : 90;

    if (!deleting && charIndex === currentRole.length) {
        deleting = true;
        delay = 1300;
    } else if (deleting && charIndex === 0) {
        deleting = false;
        roleIndex = (roleIndex + 1) % roles.length;
        delay = 350;
    }

    setTimeout(typeEffect, delay);
}

if (typingText) {
    if (prefersReducedMotion) {
        // No animation: just show the first role
        typingText.textContent = roles[0];
    } else {
        typeEffect();
    }
}


/* ===== 2. Automatically Update Footer Year ===== */

const yearElement = document.getElementById("year");

if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
}


/* ===== 3. Reveal Sections When Scrolling ===== */

const sections = document.querySelectorAll(".section");

if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
        (entries, observerInstance) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                    observerInstance.unobserve(entry.target);
                }
            });
        },
        {
            threshold: 0.12
        }
    );

    sections.forEach((section) => {
        section.classList.add("reveal");
        observer.observe(section);
    });
} else {
    sections.forEach((section) => {
        section.classList.add("visible");
    });
}


/* ===== 4. Mobile Menu ===== */

const navToggle = document.getElementById("nav-toggle");
const navLinks = document.getElementById("nav-links");

function setMenu(open) {
    navLinks.classList.toggle("open", open);
    navToggle.setAttribute("aria-expanded", String(open));
}

if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
        setMenu(!navLinks.classList.contains("open"));
    });

    // Close the menu after choosing a link
    navLinks.querySelectorAll("a").forEach((link) => {
        link.addEventListener("click", () => setMenu(false));
    });

    // Close the menu with the Escape key
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            setMenu(false);
        }
    });
}


/* ===== 5. Highlight Current Section in the Nav ===== */

const navAnchors = document.querySelectorAll(".nav-links a");
const trackedSections = document.querySelectorAll("main section[id]");

if ("IntersectionObserver" in window && navAnchors.length) {
    const navObserver = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    navAnchors.forEach((anchor) => {
                        const isCurrent =
                            anchor.getAttribute("href") === "#" + entry.target.id;
                        if (isCurrent) {
                            anchor.setAttribute("aria-current", "true");
                        } else {
                            anchor.removeAttribute("aria-current");
                        }
                    });
                }
            });
        },
        {
            // Treat the band around the upper-middle of the screen as "current"
            rootMargin: "-35% 0px -55% 0px"
        }
    );

    trackedSections.forEach((section) => navObserver.observe(section));
}
